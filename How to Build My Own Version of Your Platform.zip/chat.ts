/**
 * Chat API Handler
 *
 * Registers all chat-related Express routes including streaming AI responses,
 * conversation management, and file uploads.
 */
import type { Express } from "express";
import { chatRouter } from "../chatRouter";
import { uploadRouter } from "../uploadRouter";

export function registerChatRoutes(app: Express) {
  app.use("/api/chat", chatRouter);
  app.use("/api/upload", uploadRouter);
}
