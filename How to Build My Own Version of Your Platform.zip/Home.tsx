// Home is handled by LandingPage via App.tsx routing
export { default } from "./LandingPage";
