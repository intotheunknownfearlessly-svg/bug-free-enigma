import { Router } from "express";
import { nanoid } from "nanoid";
import { storagePut } from "./storage";
import { saveFileAttachment } from "./db";
import { sdk } from "./_core/sdk";

export const uploadRouter = Router();

// POST /api/upload — upload a file and return its public URL
uploadRouter.post("/", async (req, res) => {
  try {
    // Authenticate user
    let user = null;
    try {
      user = await sdk.authenticateRequest(req as any);
    } catch {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const { filename, mimeType, data, conversationId } = req.body as {
      filename: string;
      mimeType: string;
      data: string; // base64 encoded
      conversationId?: string;
    };

    if (!filename || !mimeType || !data) {
      res.status(400).json({ error: "filename, mimeType, and data are required" });
      return;
    }

    // Decode base64 data
    const buffer = Buffer.from(data, "base64");

    if (buffer.length > 20 * 1024 * 1024) {
      res.status(413).json({ error: "File too large (max 20MB)" });
      return;
    }

    // Upload to S3
    const suffix = nanoid(8);
    const ext = filename.split(".").pop() || "bin";
    const fileKey = `uploads/${user.id}/${nanoid()}-${suffix}.${ext}`;
    const { url } = await storagePut(fileKey, buffer, mimeType);

    // Save metadata to DB
    await saveFileAttachment({
      userId: user.id,
      conversationId,
      filename,
      mimeType,
      fileKey,
      url,
      sizeBytes: buffer.length,
    });

    res.json({ url, filename, mimeType, sizeBytes: buffer.length });
  } catch (err) {
    console.error("[Upload] Error:", err);
    res.status(500).json({ error: "Upload failed" });
  }
});
