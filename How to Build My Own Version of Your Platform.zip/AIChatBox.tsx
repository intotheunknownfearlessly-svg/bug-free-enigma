      <div className="bg-muted rounded-lg px-4 py-2.5">
        <div className="flex items-center gap-2">
          <Loader2 className="size-4 animate-spin" />
          <span className="text-sm text-muted-foreground">Thinking...</span>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export function AIChatBox({
  api = "/api/chat",
  chatId,
  userId,
  initialMessages,
  onFinish,
  renderToolPart = () => null, // Default returns null to use DefaultToolPartRenderer
  placeholder = "Type your message...",
  className,
  emptyStateMessage = "Start a conversation with AI",
  suggestedPrompts,
}: AIChatBoxProps) {
  const [input, setInput] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // -------------------------------------------------------------------------
  // useChat hook - the core of AI SDK integration
  // -------------------------------------------------------------------------
  const { messages, sendMessage, setMessages, status, error } = useChat({
    // Chat ID helps AI SDK track different conversations
    id: chatId,

    // Initial messages from your data layer (React Query, etc.)
    // Note: This makes it "controlled" - we sync via setMessages on changes
    messages: initialMessages,

    // Transport configuration - how messages are sent to the server
    transport: new DefaultChatTransport({
      api,
      // Customize the request body sent to your server
      prepareSendMessagesRequest({ messages, id }) {
        // Send only the latest message + metadata
        // Server should load full history from DB using chatId
        return {
          body: {
            message: messages[messages.length - 1],
            chatId: chatId || id,
            userId,
          },
        };
      },
    }),

    // Called when streaming completes
    onFinish: ({ messages: finalMessages, isError, isAbort, isDisconnect }) => {
      if (!isError && !isAbort && !isDisconnect) {
        // Notify parent to update cache/persist
        onFinish?.(finalMessages);
      }
    },
  });

  // -------------------------------------------------------------------------
  // Sync messages when chatId or initialMessages change (chat switching)
  // -------------------------------------------------------------------------
  useEffect(() => {
    setMessages(initialMessages);
  }, [chatId, initialMessages, setMessages]);

  // -------------------------------------------------------------------------
  // Derived state
  // -------------------------------------------------------------------------
  const canSend = status === "ready";
  const isStreaming = status === "streaming";
  const lastMessage = messages[messages.length - 1];
  const isWaitingForContent =
    status === "submitted" ||
    (isStreaming && lastMessage?.role === "assistant" && lastMessage?.parts.length === 0);

  // -------------------------------------------------------------------------
  // Auto-scroll on new messages
  // -------------------------------------------------------------------------
  useEffect(() => {
    const viewport = scrollAreaRef.current?.querySelector(
      "[data-radix-scroll-area-viewport]"
    ) as HTMLDivElement;
    if (viewport) {
      requestAnimationFrame(() => {
        viewport.scrollTo({ top: viewport.scrollHeight, behavior: "smooth" });
      });
    }
  }, [messages, status]);

  // -------------------------------------------------------------------------
  // Message submission
  // -------------------------------------------------------------------------
  const submitMessage = () => {
    const trimmedInput = input.trim();
    if (!trimmedInput || !canSend) return;

    // AI SDK v6 sendMessage accepts { text, files? }
    sendMessage({ text: trimmedInput });
    setInput("");
    textareaRef.current?.focus();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitMessage();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submitMessage();
    }
  };

  // -------------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------------
  return (
    <div className={cn("flex flex-col flex-1 min-h-0", className)}>
      {/* Messages Area */}
      <div ref={scrollAreaRef} className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <div className="mx-auto max-w-3xl space-y-4 p-4">
            {/* Empty state */}
            {messages.length === 0 && !isWaitingForContent ? (
              <div className="flex h-[60vh] flex-col items-center justify-center gap-6 text-muted-foreground">
                <Sparkles className="size-12 opacity-20" />
                <p className="text-center max-w-md">{emptyStateMessage}</p>
                {suggestedPrompts && suggestedPrompts.length > 0 && (
                  <div className="flex flex-wrap justify-center gap-2 max-w-lg">
                    {suggestedPrompts.map((prompt, i) => (
                      <Button
                        key={i}
                        variant="outline"
                        size="sm"
                        className="text-xs"
                        onClick={() => {
                          setInput(prompt);
                          textareaRef.current?.focus();
                        }}
                      >
                        {prompt}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <>
                {/* Message list */}
                {messages.map((message, index) => {
                  const isLastAssistant =
                    index === messages.length - 1 && message.role === "assistant";
                  const hasContent = message.parts.length > 0;

                  // Skip empty assistant messages (thinking indicator shows instead)
                  if (isLastAssistant && !hasContent) return null;

                  return (
                    <MessageBubble
                      key={message.id}
                      message={message}
                      renderToolPart={renderToolPart}
                      isStreaming={isStreaming && isLastAssistant && hasContent}
                    />
                  );
                })}

                {/* Thinking indicator */}
                {isWaitingForContent && <ThinkingIndicator />}
              </>
            )}

            {/* Error display */}
            {error && (
              <div className="rounded-lg bg-destructive/10 p-4 text-destructive">
                Error: {error.message}
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="border-t bg-background/50 p-4">
        <div className="mx-auto max-w-3xl">
          <div className="flex gap-2">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              className="min-h-[44px] max-h-32 resize-none"
              rows={1}
              disabled={!canSend}
            />
            <Button
              type="submit"
              size="icon"
              disabled={!canSend || !input.trim()}
              className="shrink-0 h-[44px] w-[44px]"
            >
              {status === "submitted" ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Send className="size-4" />
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}

export default AIChatBox;
