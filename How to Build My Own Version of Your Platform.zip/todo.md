# Project TODO — Manus AI Agent Platform

## Phase 1: Foundation
- [x] Database schema (conversations, messages, file_attachments)
- [x] tRPC routers for conversations and messages
- [x] AI SDK streaming integration

## Phase 2: Core Chat UI
- [x] Responsive app layout with sidebar + chat area
- [x] Real-time streaming chat interface
- [x] Multi-turn conversation with context retention
- [x] Markdown rendering with syntax highlighting
- [x] Code block copy button

## Phase 3: Conversation History & File Uploads
- [x] Conversation list in sidebar (create, rename, delete)
- [x] Conversation search
- [x] Resume past conversations
- [x] File upload UI (PDF, images, text, code) with drag-and-drop
- [x] Document analysis (extract and send file content to AI)

## Phase 4: Web Search & Code Execution
- [x] Web search integration (fetch real-time info)
- [x] Code execution sandbox (run code snippets)
- [x] Display search results and code output in chat

## Phase 5: Auth, Profile & Polish
- [x] OAuth login / logout
- [x] User profile display
- [x] Session management
- [x] Responsive design (desktop, tablet, mobile)
- [x] Empty states and loading skeletons
- [x] Vitest unit tests (9 tests passing)

## Future Improvements
- [ ] Voice input (speech-to-text transcription)
- [ ] Image generation
- [ ] Export conversation as Markdown/PDF
- [ ] Message editing and regeneration
- [ ] Custom system prompt per conversation
- [ ] Model selector (GPT-4o, Claude, etc.)
