import { and, desc, eq, like, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import type { UIMessage } from "ai";
import { nanoid } from "nanoid";
import {
  conversations,
  fileAttachments,
  InsertUser,
  messages,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    for (const field of textFields) {
      const value = user[field];
      if (value === undefined) continue;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    }

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Conversations ─────────────────────────────────────────────────────────────

export async function createConversation(userId: number, title = "New Chat") {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const id = nanoid();
  await db.insert(conversations).values({ id, userId, title });
  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result[0]!;
}

export async function getConversations(userId: number, search?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(conversations.userId, userId)];
  if (search) conditions.push(like(conversations.title, `%${search}%`));
  return db
    .select()
    .from(conversations)
    .where(and(...conditions))
    .orderBy(desc(conversations.updatedAt))
    .limit(100);
}

export async function getConversation(id: string, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId)))
    .limit(1);
  return result[0];
}

export async function updateConversationTitle(id: string, userId: number, title: string) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(conversations)
    .set({ title })
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId)));
}

export async function deleteConversation(id: string, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(messages)
    .where(eq(messages.conversationId, id));
  await db
    .delete(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId)));
}

export async function touchConversation(id: string) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(conversations)
    .set({ updatedAt: new Date() })
    .where(eq(conversations.id, id));
}

// ─── Messages ─────────────────────────────────────────────────────────────────

export async function loadMessages(conversationId: string): Promise<UIMessage[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.ordering);
  return rows.map((r) => r.content as UIMessage);
}

export async function appendMessage(conversationId: string, message: UIMessage): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const countResult = await db
    .select({ count: sql<number>`count(*)` })
    .from(messages)
    .where(eq(messages.conversationId, conversationId));
  const ordering = Number(countResult[0]?.count ?? 0);

  await db.insert(messages).values({
    id: message.id ?? nanoid(),
    conversationId,
    content: message as unknown as Record<string, unknown>,
    ordering,
  });

  await touchConversation(conversationId);
}

export async function deleteMessages(conversationId: string): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(messages).where(eq(messages.conversationId, conversationId));
}

// ─── File Attachments ─────────────────────────────────────────────────────────

export async function saveFileAttachment(data: {
  userId: number;
  conversationId?: string;
  filename: string;
  mimeType: string;
  fileKey: string;
  url: string;
  sizeBytes?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const id = nanoid();
  await db.insert(fileAttachments).values({ id, ...data });
  return id;
}
