/**
 * ChatInput — Enhanced input area with file upload, drag-and-drop, and send button.
 */
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { useFileUpload } from "@/hooks/useFileUpload";
import { Loader2, Paperclip, Send, X, FileText, Image, Code } from "lucide-react";
import { useRef, useState, useCallback, useEffect } from "react";
import type { FileUIPart } from "ai";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface ChatInputProps {
  onSend: (text: string, files?: FileUIPart[]) => void;
  disabled?: boolean;
  isLoading?: boolean;
  chatId?: string;
  placeholder?: string;
}

function getFileIcon(mimeType: string) {
  if (mimeType.startsWith("image/")) return Image;
  if (mimeType.includes("text") || mimeType.includes("code")) return Code;
  return FileText;
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function ChatInput({
  onSend,
  disabled,
  isLoading,
  chatId,
  placeholder = "Message Manus AI...",
}: ChatInputProps) {
  const [input, setInput] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Upload function via tRPC-backed API
  const uploadMutation = trpc.useUtils();
  const uploadFn = useCallback(
    async (file: File): Promise<string> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            const base64 = (reader.result as string).split(",")[1];
            const response = await fetch("/api/upload", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                filename: file.name,
                mimeType: file.type,
                data: base64,
                conversationId: chatId,
              }),
            });
            if (!response.ok) throw new Error("Upload failed");
            const data = await response.json() as { url: string };
            resolve(data.url);
          } catch (err) {
            reject(err);
          }
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    },
    [chatId]
  );

  const { files, addFiles, removeFile, clearFiles, getUploadedFiles, isUploading } =
    useFileUpload({
      uploadFn,
      accept: [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "application/pdf",
        "text/plain",
        "text/markdown",
        "text/csv",
        "application/json",
        "text/javascript",
        "text/typescript",
        "text/html",
        "text/css",
        "text/x-python",
        "application/x-python-code",
      ],
      maxSize: 20 * 1024 * 1024,
    });

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 200)}px`;
  }, [input]);

  const canSend = !disabled && !isLoading && !isUploading && (input.trim() || files.length > 0);

  const handleSubmit = () => {
    if (!canSend) return;
    const uploadedFiles = getUploadedFiles();
    onSend(input.trim(), uploadedFiles.length > 0 ? uploadedFiles : undefined);
    setInput("");
    clearFiles();
    textareaRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Drag-and-drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = () => setIsDragging(false);
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    if (droppedFiles.length > 0) addFiles(droppedFiles);
  };

  return (
    <div
      className={cn(
        "border-t border-border/50 bg-background/80 backdrop-blur-sm p-4 transition-colors",
        isDragging && "bg-primary/5 border-primary/30"
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="mx-auto max-w-3xl space-y-3">
        {/* File previews */}
        {files.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {files.map((f) => {
              const Icon = getFileIcon(f.file.type);
              return (
                <div
                  key={f.id}
                  className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm transition-colors",
                    f.status === "uploading" && "border-border/50 bg-muted/30",
                    f.status === "success" && "border-primary/30 bg-primary/5",
                    f.status === "error" && "border-destructive/30 bg-destructive/5"
                  )}
                >
                  {f.status === "uploading" ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />
                  ) : (
                    <Icon className="w-3.5 h-3.5 text-primary shrink-0" />
                  )}
                  <span className="max-w-[120px] truncate text-xs text-foreground/80">
                    {f.file.name}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {formatBytes(f.file.size)}
                  </span>
                  <button
                    onClick={() => removeFile(f.id)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* Input row */}
        <div
          className={cn(
            "flex items-end gap-2 rounded-xl border bg-card/50 px-3 py-2 transition-colors",
            isDragging ? "border-primary/50" : "border-border/50",
            "focus-within:border-primary/50"
          )}
        >
          {/* Attach button */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 text-muted-foreground hover:text-foreground"
                onClick={() => fileInputRef.current?.click()}
                disabled={disabled}
              >
                <Paperclip className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Attach file (PDF, image, text, code)</TooltipContent>
          </Tooltip>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            accept="image/*,.pdf,.txt,.md,.csv,.json,.js,.ts,.html,.css,.py"
            onChange={(e) => {
              if (e.target.files) addFiles(e.target.files);
              e.target.value = "";
            }}
          />

          {/* Textarea */}
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isDragging ? "Drop files here..." : placeholder}
            className="flex-1 min-h-[40px] max-h-[200px] resize-none border-0 bg-transparent p-0 focus-visible:ring-0 text-sm leading-relaxed"
            rows={1}
            disabled={disabled}
          />

          {/* Send button */}
          <Button
            type="button"
            size="icon"
            className={cn(
              "h-8 w-8 shrink-0 rounded-lg transition-all",
              canSend
                ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                : "bg-muted text-muted-foreground cursor-not-allowed"
            )}
            onClick={handleSubmit}
            disabled={!canSend}
          >
            {isLoading || isUploading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>

        <p className="text-center text-xs text-muted-foreground/50">
          Shift+Enter for new line · Drag & drop files to attach
        </p>
      </div>
    </div>
  );
}

// Import Tooltip for the attach button
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
