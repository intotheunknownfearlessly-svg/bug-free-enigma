import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useEffect } from "react";
import { useLocation } from "wouter";
import { Sparkles, MessageSquare, Search, Code2, FileText, Zap, Shield } from "lucide-react";

const features = [
  {
    icon: MessageSquare,
    title: "Multi-turn Conversations",
    description: "Engage in deep, context-aware conversations that remember everything you've discussed.",
  },
  {
    icon: Search,
    title: "Real-time Web Search",
    description: "Get up-to-date information from the internet, integrated seamlessly into responses.",
  },
  {
    icon: Code2,
    title: "Code Execution",
    description: "Run JavaScript code snippets directly in the chat and see results instantly.",
  },
  {
    icon: FileText,
    title: "Document Analysis",
    description: "Upload PDFs, images, and text files for the AI to read and analyze.",
  },
  {
    icon: Zap,
    title: "Streaming Responses",
    description: "Watch answers appear in real-time with smooth token-by-token streaming.",
  },
  {
    icon: Shield,
    title: "Conversation History",
    description: "All your chats are saved and searchable. Pick up where you left off anytime.",
  },
];

export default function LandingPage() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && user) {
      setLocation("/chat");
    }
  }, [user, loading, setLocation]);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 px-6 py-4 flex items-center justify-between backdrop-blur-sm sticky top-0 z-10 bg-background/80">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <span className="font-semibold text-lg tracking-tight">Manus AI</span>
        </div>
        <Button
          onClick={() => (window.location.href = getLoginUrl())}
          size="sm"
          className="bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          Sign in
        </Button>
      </header>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 py-20 text-center">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
            <Sparkles className="w-3.5 h-3.5" />
            Powered by Gemini 2.5 Flash
          </div>

          <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight">
            Your personal
            <span className="text-primary"> AI assistant</span>
          </h1>

          <p className="text-xl text-muted-foreground max-w-xl mx-auto leading-relaxed">
            A full-featured AI platform with real-time streaming, web search, code execution, file analysis, and persistent conversation history.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 h-12 text-base font-medium shadow-lg shadow-primary/25"
              onClick={() => (window.location.href = getLoginUrl())}
            >
              Get started for free
            </Button>
          </div>
        </div>

        {/* Features grid */}
        <div className="mt-24 max-w-5xl mx-auto w-full">
          <h2 className="text-2xl font-semibold text-center mb-12 text-foreground/80">
            Everything you need in one place
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="p-6 rounded-xl bg-card border border-border/50 text-left hover:border-primary/30 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold mb-2 text-foreground">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 px-6 py-6 text-center text-sm text-muted-foreground">
        Built with the Manus platform
      </footer>
    </div>
  );
}
