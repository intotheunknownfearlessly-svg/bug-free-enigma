import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Markdown } from "@/components/Markdown";
import { ChatInput } from "@/components/ChatInput";
import { cn } from "@/lib/utils";
import {
  Code2,
  Edit2,
  FileText,
  Image as ImageIcon,
  Loader2,
  LogOut,
  MessageSquare,
  MoreHorizontal,
  PanelLeft,
  PlusCircle,
  Search,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { useLocation, useParams } from "wouter";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import type { UIMessage, FileUIPart } from "ai";
import { toast } from "sonner";

// ─── Tool Renderers ───────────────────────────────────────────────────────────

function WebSearchResult({ output }: { output: unknown }) {
  const data = output as {
    query: string;
    results: Array<{ title: string; url: string; snippet: string }>;
  };
  if (!data?.results?.length) {
    return (
      <div className="text-sm text-muted-foreground p-3 bg-muted/30 rounded-lg">
        No results found for "{data?.query}"
      </div>
    );
  }
  return (
    <div className="my-2 rounded-lg border border-border/50 overflow-hidden text-sm">
      <div className="px-3 py-2 bg-muted/30 border-b border-border/50 flex items-center gap-2">
        <Search className="w-3.5 h-3.5 text-primary" />
        <span className="text-xs font-medium text-muted-foreground">
          Web search: "{data.query}"
        </span>
      </div>
      <div className="divide-y divide-border/30">
        {data.results.map((r, i) => (
          <div key={i} className="px-3 py-2.5">
            <a
              href={r.url}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-primary hover:underline line-clamp-1 text-sm"
            >
              {r.title}
            </a>
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{r.snippet}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function CodeExecutionResult({ output }: { output: unknown }) {
  const data = output as {
    language: string;
    output: string;
    errors: string;
    result?: string;
    executionTime: string;
    success: boolean;
  };
  return (
    <div className="my-2 rounded-lg border border-border/50 overflow-hidden text-sm">
      <div className="px-3 py-2 bg-muted/30 border-b border-border/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Code2 className="w-3.5 h-3.5 text-primary" />
          <span className="text-xs font-medium text-muted-foreground">
            Code execution ({data?.language})
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "text-xs px-1.5 py-0.5 rounded-full",
              data?.success ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
            )}
          >
            {data?.success ? "Success" : "Error"}
          </span>
          <span className="text-xs text-muted-foreground">{data?.executionTime}</span>
        </div>
      </div>
      {data?.output && (
        <div className="px-3 py-2.5">
          <pre className="text-xs font-mono text-foreground/80 whitespace-pre-wrap bg-muted/20 rounded p-2 overflow-x-auto">
            {data.output}
          </pre>
        </div>
      )}
      {data?.errors && (
        <div className="px-3 py-2.5 border-t border-border/30">
          <pre className="text-xs font-mono text-red-400/80 whitespace-pre-wrap bg-red-500/5 rounded p-2 overflow-x-auto">
            {data.errors}
          </pre>
        </div>
      )}
      {data?.result !== undefined && (
        <div className="px-3 py-2 border-t border-border/30">
          <span className="text-xs text-muted-foreground">Return value: </span>
          <code className="text-xs text-primary">{data.result}</code>
        </div>
      )}
    </div>
  );
}

// ─── Message Bubble ───────────────────────────────────────────────────────────

function MessageBubble({
  message,
  isStreaming,
}: {
  message: UIMessage;
  isStreaming: boolean;
}) {
  const isUser = message.role === "user";

  return (
    <div className={cn("flex gap-3 group", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <div className="w-8 h-8 shrink-0 mt-1 rounded-full bg-primary/15 flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-primary" />
        </div>
      )}

      <div
        className={cn(
          "max-w-[80%] rounded-2xl px-4 py-3 space-y-2",
          isUser
            ? "bg-primary text-primary-foreground rounded-tr-sm"
            : "bg-card border border-border/50 text-foreground rounded-tl-sm"
        )}
      >
        {message.parts.map((part, i) => {
          if (part.type === "text") {
            if (!part.text && isStreaming) {
              return (
                <div key={i} className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60 animate-bounce [animation-delay:0ms]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60 animate-bounce [animation-delay:150ms]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60 animate-bounce [animation-delay:300ms]" />
                  </div>
                </div>
              );
            }
            return (
              <div
                key={i}
                className={cn(
                  "prose prose-sm max-w-none",
                  isUser ? "prose-invert" : "dark:prose-invert"
                )}
              >
                <Markdown mode={isStreaming ? "streaming" : "static"}>{part.text}</Markdown>
              </div>
            );
          }

          if (part.type === "file") {
            const fileUrl = (part as { type: "file"; url: string; mediaType: string }).url;
            const mediaType = (part as { type: "file"; url: string; mediaType: string }).mediaType;
            if (mediaType?.startsWith("image/")) {
              return (
                <img
                  key={i}
                  src={fileUrl}
                  alt="Uploaded image"
                  className="max-w-xs rounded-lg border border-border/30"
                />
              );
            }
            return (
              <div key={i} className="flex items-center gap-2 text-xs opacity-80">
                <FileText className="w-3.5 h-3.5" />
                <span>Attached file</span>
              </div>
            );
          }

          if (part.type.startsWith("tool-")) {
            const toolName = part.type.replace("tool-", "");
            const toolPart = part as {
              type: `tool-${string}`;
              state: string;
              input?: unknown;
              output?: unknown;
              errorText?: string;
            };

            if (toolPart.state === "input-streaming" || toolPart.state === "input-available") {
              return (
                <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground py-1">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>
                    {toolName === "webSearch" ? "Searching the web..." : "Running code..."}
                  </span>
                </div>
              );
            }

            if (toolPart.state === "output-available") {
              if (toolName === "webSearch") return <WebSearchResult key={i} output={toolPart.output} />;
              if (toolName === "executeCode") return <CodeExecutionResult key={i} output={toolPart.output} />;
            }

            if (toolPart.state === "output-error") {
              return (
                <div key={i} className="text-xs text-destructive p-2 bg-destructive/10 rounded">
                  Tool error: {toolPart.errorText}
                </div>
              );
            }
          }

          return null;
        })}
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function ConversationSidebar({
  currentId,
  onSelect,
  onNew,
  isOpen,
  onClose,
}: {
  currentId?: string;
  onSelect: (id: string) => void;
  onNew: () => void;
  isOpen: boolean;
  onClose: () => void;
}) {
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const utils = trpc.useUtils();

  const { data: conversations = [], isLoading } = trpc.conversations.list.useQuery(
    { search: search || undefined },
    { refetchInterval: 5000 }
  );

  const renameMutation = trpc.conversations.rename.useMutation({
    onSuccess: () => {
      utils.conversations.list.invalidate();
      setEditingId(null);
    },
  });

  const deleteMutation = trpc.conversations.delete.useMutation({
    onSuccess: (_, vars) => {
      utils.conversations.list.invalidate();
      if (vars.id === currentId) onNew();
    },
    onError: () => toast.error("Failed to delete conversation"),
  });

  const handleRename = (id: string) => {
    if (!editTitle.trim()) { setEditingId(null); return; }
    renameMutation.mutate({ id, title: editTitle.trim() });
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/60 z-20 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={cn(
          "fixed lg:relative inset-y-0 left-0 z-30 flex flex-col w-72 bg-sidebar border-r border-sidebar-border transition-transform duration-200 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
            </div>
            <span className="font-semibold text-sm text-sidebar-foreground">Manus AI</span>
          </div>
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onNew}>
                  <PlusCircle className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>New chat</TooltipContent>
            </Tooltip>
            <Button variant="ghost" size="icon" className="h-7 w-7 lg:hidden" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="px-3 py-2.5">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search chats..."
              className="pl-8 h-8 text-sm bg-muted/40 border-0 focus-visible:ring-1 focus-visible:ring-primary/50"
            />
          </div>
        </div>

        {/* List */}
        <ScrollArea className="flex-1 px-2">
          {isLoading ? (
            <div className="space-y-1 p-1">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-9 rounded-lg bg-muted/20 animate-pulse" />
              ))}
            </div>
          ) : conversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-center px-4">
              <MessageSquare className="w-7 h-7 text-muted-foreground/30 mb-2" />
              <p className="text-xs text-muted-foreground">
                {search ? "No chats found" : "No conversations yet"}
              </p>
              {!search && (
                <Button variant="ghost" size="sm" className="mt-2 text-primary text-xs h-7" onClick={onNew}>
                  Start chatting
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-0.5 py-1">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  className={cn(
                    "group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors",
                    conv.id === currentId
                      ? "bg-primary/15 text-foreground"
                      : "hover:bg-accent/50 text-sidebar-foreground"
                  )}
                  onClick={() => { onSelect(conv.id); onClose(); }}
                >
                  {editingId === conv.id ? (
                    <input
                      autoFocus
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      onBlur={() => handleRename(conv.id)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleRename(conv.id);
                        if (e.key === "Escape") setEditingId(null);
                      }}
                      className="flex-1 text-sm bg-transparent outline-none border-b border-primary"
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <span className="flex-1 text-sm truncate leading-snug">{conv.title}</span>
                  )}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <MoreHorizontal className="w-3.5 h-3.5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40">
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingId(conv.id);
                          setEditTitle(conv.title);
                        }}
                      >
                        <Edit2 className="w-3.5 h-3.5 mr-2" />
                        Rename
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteMutation.mutate({ id: conv.id });
                        }}
                      >
                        <Trash2 className="w-3.5 h-3.5 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        {/* User footer */}
        <UserFooter />
      </aside>
    </>
  );
}

function UserFooter() {
  const { user, logout } = useAuth();
  if (!user) return null;
  return (
    <div className="border-t border-sidebar-border p-3">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-3 w-full px-2 py-1.5 rounded-lg hover:bg-accent/50 transition-colors text-left">
            <Avatar className="h-8 w-8 border border-border shrink-0">
              <AvatarFallback className="text-xs bg-primary/20 text-primary font-medium">
                {user.name?.charAt(0).toUpperCase() ?? "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate text-sidebar-foreground">{user.name || "User"}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email || ""}</p>
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem
            onClick={logout}
            className="text-destructive focus:text-destructive cursor-pointer"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

// ─── Chat Area ────────────────────────────────────────────────────────────────

function ChatArea({
  chatId,
  userId,
  initialMessages,
  onFinish,
}: {
  chatId: string;
  userId: number;
  initialMessages: UIMessage[];
  onFinish: (messages: UIMessage[]) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const { messages, sendMessage, setMessages, status, error } = useChat({
    id: chatId,
    messages: initialMessages,
    transport: new DefaultChatTransport({
      api: "/api/chat",
      prepareSendMessagesRequest({ messages: msgs, id }) {
        return {
          body: {
            message: msgs[msgs.length - 1],
            chatId: chatId || id,
            userId,
          },
        };
      },
    }),
    onFinish: ({ messages: finalMessages, isError, isAbort }) => {
      if (!isError && !isAbort) onFinish(finalMessages);
    },
  });

  // Sync on chat switch
  useEffect(() => {
    setMessages(initialMessages);
  }, [chatId, initialMessages, setMessages]);

  // Auto-scroll
  useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      requestAnimationFrame(() => {
        el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
      });
    }
  }, [messages, status]);

  const isStreaming = status === "streaming";
  const isWaiting = status === "submitted";
  const canSend = status === "ready";

  const handleSend = (text: string, files?: FileUIPart[]) => {
    if (!canSend) return;
    const parts: UIMessage["parts"] = [];
    if (files?.length) {
      parts.push(...files);
    }
    if (text) parts.push({ type: "text", text });
    sendMessage({ parts });
  };

  const suggestedPrompts = [
    "Explain quantum computing in simple terms",
    "Search the web for the latest AI news",
    "Write and execute a Fibonacci sequence in JavaScript",
    "Help me analyze this document",
  ];

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl px-4 py-6 space-y-6">
          {messages.length === 0 && !isWaiting ? (
            <div className="flex flex-col items-center justify-center min-h-[50vh] gap-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Sparkles className="w-7 h-7 text-primary" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-semibold">How can I help you today?</h2>
                <p className="text-sm text-muted-foreground max-w-sm">
                  I can search the web, run code, analyze files, and answer any question.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-lg">
                {suggestedPrompts.map((prompt) => (
                  <button
                    key={prompt}
                    onClick={() => handleSend(prompt)}
                    className="text-left px-4 py-3 rounded-xl border border-border/50 bg-card/50 hover:bg-card hover:border-primary/30 transition-colors text-sm text-muted-foreground hover:text-foreground"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((msg, idx) => {
                const isLast = idx === messages.length - 1;
                const isLastAssistant = isLast && msg.role === "assistant";
                if (isLastAssistant && msg.parts.length === 0) return null;
                return (
                  <MessageBubble
                    key={msg.id}
                    message={msg}
                    isStreaming={isStreaming && isLastAssistant}
                  />
                );
              })}

              {/* Thinking indicator */}
              {(isWaiting || (isStreaming && messages[messages.length - 1]?.parts.length === 0)) && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 shrink-0 mt-1 rounded-full bg-primary/15 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-primary" />
                  </div>
                  <div className="bg-card border border-border/50 rounded-2xl rounded-tl-sm px-4 py-3">
                    <div className="flex gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce [animation-delay:0ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce [animation-delay:150ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce [animation-delay:300ms]" />
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {error && (
            <div className="rounded-xl bg-destructive/10 border border-destructive/20 p-4 text-sm text-destructive">
              Error: {error.message}
            </div>
          )}
        </div>
      </div>

      {/* Input */}
      <ChatInput
        onSend={handleSend}
        disabled={!canSend}
        isLoading={isWaiting || isStreaming}
        chatId={chatId}
        placeholder="Message Manus AI... (Shift+Enter for new line)"
      />
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function ChatPage() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams<{ id?: string }>();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentChatId, setCurrentChatId] = useState<string | null>(params.id ?? null);
  const utils = trpc.useUtils();

  useEffect(() => {
    if (!loading && !user) {
      window.location.href = getLoginUrl();
    }
  }, [user, loading]);

  useEffect(() => {
    if (params.id && params.id !== currentChatId) {
      setCurrentChatId(params.id);
    }
  }, [params.id]);

  const createConversation = trpc.conversations.create.useMutation({
    onSuccess: (conv) => {
      utils.conversations.list.invalidate();
      setCurrentChatId(conv.id);
      setLocation(`/chat/${conv.id}`);
    },
    onError: () => toast.error("Failed to create conversation"),
  });

  const handleNewChat = useCallback(() => {
    createConversation.mutate({ title: "New Chat" });
  }, [createConversation]);

  const handleSelectConversation = useCallback(
    (id: string) => {
      setCurrentChatId(id);
      setLocation(`/chat/${id}`);
    },
    [setLocation]
  );

  const messagesQuery = trpc.conversations.loadMessages.useQuery(
    { id: currentChatId! },
    { enabled: !!currentChatId, staleTime: 30_000 }
  );

  const handleFinish = useCallback(
    (messages: UIMessage[]) => {
      if (currentChatId) {
        utils.conversations.loadMessages.setData({ id: currentChatId }, messages);
        utils.conversations.list.invalidate();
      }
    },
    [currentChatId, utils]
  );

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="flex items-center gap-3 text-muted-foreground">
          <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          <span className="text-sm">Loading...</span>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <ConversationSidebar
        currentId={currentChatId ?? undefined}
        onSelect={handleSelectConversation}
        onNew={handleNewChat}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <div className="flex-1 flex flex-col min-w-0 h-screen">
        {/* Top bar */}
        <header className="flex items-center gap-3 px-4 h-14 border-b border-border/50 shrink-0 bg-background/80 backdrop-blur-sm">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setSidebarOpen((v) => !v)}
          >
            <PanelLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <span className="text-sm text-muted-foreground">
              {currentChatId
                ? messagesQuery.isLoading
                  ? "Loading..."
                  : `${messagesQuery.data?.length ?? 0} messages`
                : "New conversation"}
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-sm h-8"
            onClick={handleNewChat}
            disabled={createConversation.isPending}
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">New chat</span>
          </Button>
        </header>

        {/* Chat or empty state */}
        {currentChatId ? (
          messagesQuery.isLoading ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="text-sm">Loading messages...</span>
              </div>
            </div>
          ) : (
            <ChatArea
              key={currentChatId}
              chatId={currentChatId}
              userId={user.id}
              initialMessages={messagesQuery.data ?? []}
              onFinish={handleFinish}
            />
          )
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center gap-6 p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-semibold">Welcome to Manus AI</h2>
              <p className="text-muted-foreground max-w-sm text-sm">
                Start a new conversation to chat with your AI assistant.
              </p>
            </div>
            <Button
              size="lg"
              onClick={handleNewChat}
              disabled={createConversation.isPending}
              className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
            >
              {createConversation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <PlusCircle className="w-5 h-5" />
              )}
              Start new chat
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
