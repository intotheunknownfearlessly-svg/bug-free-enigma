import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock the DB module
vi.mock("./db", () => ({
  createConversation: vi.fn().mockResolvedValue({
    id: "conv-123",
    userId: 1,
    title: "Test Chat",
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  getConversations: vi.fn().mockResolvedValue([
    {
      id: "conv-123",
      userId: 1,
      title: "Test Chat",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
  getConversation: vi.fn().mockResolvedValue({
    id: "conv-123",
    userId: 1,
    title: "Test Chat",
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  updateConversationTitle: vi.fn().mockResolvedValue(undefined),
  deleteConversation: vi.fn().mockResolvedValue(undefined),
  loadMessages: vi.fn().mockResolvedValue([
    {
      id: "msg-1",
      role: "user",
      parts: [{ type: "text", text: "Hello" }],
    },
  ]),
  deleteMessages: vi.fn().mockResolvedValue(undefined),
  appendMessage: vi.fn().mockResolvedValue(undefined),
  touchConversation: vi.fn().mockResolvedValue(undefined),
  saveFileAttachment: vi.fn().mockResolvedValue("attach-1"),
}));

function createUserContext(): TrpcContext {
  const user: User = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("conversations router", () => {
  it("creates a new conversation", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.conversations.create({ title: "Test Chat" });
    expect(result).toMatchObject({ id: "conv-123", title: "Test Chat" });
  });

  it("lists conversations", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.conversations.list({});
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
  });

  it("renames a conversation", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.conversations.rename({
      id: "conv-123",
      title: "Renamed Chat",
    });
    expect(result).toEqual({ success: true });
  });

  it("deletes a conversation", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.conversations.delete({ id: "conv-123" });
    expect(result).toEqual({ success: true });
  });

  it("loads messages for a conversation", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.conversations.loadMessages({ id: "conv-123" });
    expect(Array.isArray(result)).toBe(true);
    expect(result[0]).toMatchObject({ role: "user" });
  });

  it("throws NOT_FOUND for missing conversation", async () => {
    const { getConversation } = await import("./db");
    vi.mocked(getConversation).mockResolvedValueOnce(undefined);
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.conversations.delete({ id: "missing" })).rejects.toThrow();
  });
});

describe("auth router", () => {
  it("returns current user", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();
    expect(user).toMatchObject({ id: 1, name: "Test User" });
  });

  it("logs out and clears cookie", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
  });
});
