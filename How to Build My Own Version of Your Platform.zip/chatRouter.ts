import { Router } from "express";
import {
  convertToModelMessages,
  createUIMessageStream,
  generateId,
  pipeUIMessageStreamToResponse,
  stepCountIs,
  streamText,
  tool,
  UIMessage,
} from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { z } from "zod/v4";
import { createPatchedFetch } from "./_core/patchedFetch";
import {
  appendMessage,
  createConversation,
  loadMessages,
  touchConversation,
  updateConversationTitle,
} from "./db";
import { sdk } from "./_core/sdk";

const openai = createOpenAI({
  apiKey: process.env.BUILT_IN_FORGE_API_KEY,
  baseURL: `${process.env.BUILT_IN_FORGE_API_URL}/v1`,
  fetch: createPatchedFetch(fetch),
});

// ─── Tools ────────────────────────────────────────────────────────────────────

const webSearchTool = tool({
  description:
    "Search the web for real-time information. Use when the user asks about current events, facts, or anything that requires up-to-date information.",
  inputSchema: z.object({
    query: z.string().describe("The search query"),
  }),
  execute: async ({ query }) => {
    try {
      const response = await fetch(
        `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
      );
      const data = await response.json() as {
        AbstractText?: string;
        AbstractURL?: string;
        RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>;
      };

      const results: Array<{ title: string; url: string; snippet: string }> = [];

      if (data.AbstractText) {
        results.push({
          title: "Summary",
          url: data.AbstractURL || "",
          snippet: data.AbstractText,
        });
      }

      if (data.RelatedTopics) {
        for (const topic of data.RelatedTopics.slice(0, 5)) {
          if (topic.Text && topic.FirstURL) {
            results.push({
              title: topic.Text.split(" - ")[0] || topic.Text,
              url: topic.FirstURL,
              snippet: topic.Text,
            });
          }
        }
      }

      return {
        query,
        results: results.slice(0, 6),
        timestamp: new Date().toISOString(),
      };
    } catch (err) {
      return { query, results: [], error: "Search failed", timestamp: new Date().toISOString() };
    }
  },
});

const executeCodeTool = tool({
  description:
    "Execute JavaScript/TypeScript code in a sandboxed environment and return the output. Use for calculations, data processing, algorithm demonstrations, or testing code snippets.",
  inputSchema: z.object({
    code: z.string().describe("The JavaScript code to execute"),
    language: z
      .enum(["javascript", "typescript"])
      .default("javascript")
      .describe("Programming language"),
  }),
  execute: async ({ code, language }) => {
    const startTime = Date.now();
    const logs: string[] = [];
    const errors: string[] = [];

    try {
      // Safe sandbox using Function constructor with limited scope
      const sandboxCode = `
        const __logs = [];
        const __errors = [];
        const console = {
          log: (...args) => __logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ')),
          error: (...args) => __errors.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ')),
          warn: (...args) => __logs.push('[WARN] ' + args.map(a => String(a)).join(' ')),
          info: (...args) => __logs.push('[INFO] ' + args.map(a => String(a)).join(' ')),
        };
        let __result;
        try {
          __result = (function() {
            ${code}
          })();
        } catch(e) {
          __errors.push(e.message);
        }
        return { logs: __logs, errors: __errors, result: __result };
      `;

      // eslint-disable-next-line no-new-func
      const fn = new Function(sandboxCode);
      const output = fn() as { logs: string[]; errors: string[]; result: unknown };
      logs.push(...(output.logs || []));
      errors.push(...(output.errors || []));

      const duration = Date.now() - startTime;
      return {
        language,
        code,
        output: logs.join("\n"),
        errors: errors.join("\n"),
        result: output.result !== undefined ? String(output.result) : undefined,
        executionTime: `${duration}ms`,
        success: errors.length === 0,
      };
    } catch (err) {
      return {
        language,
        code,
        output: "",
        errors: err instanceof Error ? err.message : "Execution failed",
        executionTime: `${Date.now() - startTime}ms`,
        success: false,
      };
    }
  },
});

const tools = {
  webSearch: webSearchTool,
  executeCode: executeCodeTool,
};

// ─── Auto-title helper ─────────────────────────────────────────────────────────

async function generateTitle(userMessage: string): Promise<string> {
  try {
    const result = await streamText({
      model: openai.chat("gemini-2.5-flash"),
      system:
        "Generate a concise, descriptive title (max 6 words) for a conversation that starts with the following user message. Return ONLY the title, no quotes, no punctuation at the end.",
      messages: [{ role: "user", content: userMessage }],
      maxOutputTokens: 20,
    });
    let title = "";
    for await (const chunk of result.textStream) {
      title += chunk;
    }
    return title.trim().slice(0, 80) || "New Chat";
  } catch {
    return "New Chat";
  }
}

// ─── Chat Router ──────────────────────────────────────────────────────────────

export const chatRouter = Router();

chatRouter.post("/", async (req, res) => {
  try {
    const { message, chatId, userId } = req.body as {
      message: UIMessage;
      chatId: string;
      userId?: number;
    };

    if (!message || !chatId) {
      res.status(400).json({ error: "message and chatId are required" });
      return;
    }

    // Verify conversation exists (or create it)
    let sessionUser = null;
    try { sessionUser = await sdk.authenticateRequest(req as any); } catch {}
    const resolvedUserId = sessionUser?.id ?? userId;

    if (!resolvedUserId) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    // Persist the incoming user message
    await appendMessage(chatId, message);

    // Auto-generate title from first user message
    const existingMessages = await loadMessages(chatId);
    const userMessages = existingMessages.filter((m) => m.role === "user");
    if (userMessages.length === 1 && message.role === "user") {
      const textPart = message.parts?.find((p) => p.type === "text");
      const text = textPart && "text" in textPart ? textPart.text : "";
      if (text) {
        generateTitle(text).then((title) =>
          updateConversationTitle(chatId, resolvedUserId, title)
        );
      }
    }

    const stream = createUIMessageStream({
      execute: async ({ writer }) => {
        writer.write({ type: "start", messageId: generateId() });

        const allMessages = await loadMessages(chatId);
        const modelMessages = await convertToModelMessages(allMessages);

        const result = streamText({
          model: openai.chat("gemini-2.5-flash"),
          system: `You are a highly capable AI assistant — intelligent, helpful, and thorough. You can:
- Answer questions and engage in multi-turn conversations
- Search the web for real-time information using the webSearch tool
- Execute JavaScript code using the executeCode tool
- Analyze files and documents shared by the user
- Write, explain, and debug code in any language
- Help with research, writing, analysis, and problem-solving

Always be clear, accurate, and helpful. When using tools, explain what you're doing.
Current date: ${new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}`,
          messages: modelMessages,
          tools,
          stopWhen: stepCountIs(10),
          maxOutputTokens: 8192,
        });

        result.consumeStream();
        writer.merge(result.toUIMessageStream({ sendStart: false }));
      },
      onFinish: async ({ messages: finalMessages }) => {
        const assistantMessage = finalMessages[finalMessages.length - 1];
        if (assistantMessage?.role === "assistant") {
          await appendMessage(chatId, assistantMessage);
        }
        await touchConversation(chatId);
      },
    });

    pipeUIMessageStreamToResponse({ response: res, stream });
  } catch (err) {
    console.error("[Chat] Error:", err);
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal server error" });
    }
  }
});

// File upload endpoint
chatRouter.post("/upload", async (req, res) => {
  res.status(200).json({ message: "Use /api/upload for file uploads" });
});
